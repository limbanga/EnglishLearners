package com.example.englishlearners.model

data class AppUser(
    var id: String = "",
    var displayName: String = "",
    var imgPath: String? = ""
)
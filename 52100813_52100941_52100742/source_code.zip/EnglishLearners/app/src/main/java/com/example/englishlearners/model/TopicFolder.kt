package com.example.englishlearners.model

data class TopicFolder(
    var topicId: String = "",
    var folderId: String = "",
)
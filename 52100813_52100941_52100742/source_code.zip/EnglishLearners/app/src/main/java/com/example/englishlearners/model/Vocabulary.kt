package com.example.englishlearners.model

data class Vocabulary(
    var id: String = "",
    var term: String = "",
    var definition: String = "",
    val topicId: String ="",
)
package com.example.englishlearners.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.englishlearners.R;

public class DetailVocabularyMultipleChoice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_vocabulary_multiple_choice);
    }
}
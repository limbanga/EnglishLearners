package com.example.englishlearners

class AppConst {
    companion object {
        const val DEBUG_TAG = "DEBUG_TAG44"

        const val KEY_TOPIC = "topics"
        const val KEY_FOLDER = "folders"
        const val KEY_VOCABULARY = "vocabularies"
        const val KEY_USER = "appUsers"
        const val KEY_TOPICS_FOLDERS = "topics_folders"
    }
}